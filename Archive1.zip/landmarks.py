import cv2
import dlib

# détecteur visage
detector = dlib.get_frontal_face_detector()

# modèle des 68 points
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# image
img = cv2.imread("demo.jpg")

if img is None:
    print("Image non trouvée")
    exit()

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

faces = detector(gray)

for face in faces:
    landmarks = predictor(gray, face)
    
    for i in range(68):
        x = landmarks.part(i).x
        y = landmarks.part(i).y
        cv2.circle(img, (x,y), 2, (0,0,255), -1)

cv2.imshow("Landmarks", img)
cv2.waitKey(0)
cv2.destroyAllWindows()