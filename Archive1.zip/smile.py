import cv2
import dlib
import numpy as np

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

cap = cv2.VideoCapture(0)

def mouth_opening(landmarks):
    top_lip = landmarks.part(62).y
    bottom_lip = landmarks.part(66).y
    return abs(bottom_lip - top_lip)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)

    for face in faces:
        landmarks = predictor(gray, face)

        # dessiner les points
        for i in range(48, 68):
            x = landmarks.part(i).x
            y = landmarks.part(i).y
            cv2.circle(frame, (x,y), 2, (0,255,0), -1)

        # calcul sourire
        distance = mouth_opening(landmarks)

        if distance > 15:
            cv2.putText(frame, "SMILE 😊", (50,50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1,
                        (0,255,0), 2)

    cv2.imshow("Smile Detection", frame)

    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()