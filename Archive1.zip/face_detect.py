import cv2
import dlib

# détecteur de visage
detector = dlib.get_frontal_face_detector()

# lire l'image
img = cv2.imread("demo.jpg")

# vérifier si image chargée
if img is None:
    print("Erreur : image non trouvée")
    exit()

# convertir en gris
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# détecter les visages
faces = detector(gray)

# dessiner les rectangles
for face in faces:
    x, y = face.left(), face.top()
    w, h = face.width(), face.height()
    cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0), 2)

# afficher
cv2.imshow("Faces", img)
cv2.waitKey(0)
cv2.destroyAllWindows()