import os
import pandas as pd
import cv2

data = []
labels_map = {
    "angry":0, "disgust":1, "fear":2,
    "happy":3, "sad":4, "surprise":5, "neutral":6
}

base_path = "train"

for label in os.listdir(base_path):
    folder = os.path.join(base_path, label)
    for file in os.listdir(folder):
        img_path = os.path.join(folder, file)
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (48,48))
        pixels = " ".join(map(str, img.flatten()))
        
        data.append([labels_map[label], pixels])

df = pd.DataFrame(data, columns=["emotion", "pixels"])
df.to_csv("fer2013.csv", index=False)